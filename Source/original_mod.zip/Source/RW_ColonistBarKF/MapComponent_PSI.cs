﻿namespace ColonistBarKF
{
    using Verse;

    public class MapComponent_PSI : MapComponent
    {
        public MapComponent_PSI(Map map)
            : base(map)
        {
            this.map = map;
        }
    }
}