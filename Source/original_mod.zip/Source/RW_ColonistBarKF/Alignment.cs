﻿namespace ColonistBarKF
{
    public static class Position
    {
        public enum Alignment
        {
            Left,

            Right,

            Top,

            Bottom
        }
    }
}